<?php

namespace FCFProVendor;

if (!\defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly
?>
<script type="text/javascript">
    <?php 
include \dirname(__FILE__) . '/../../../../assets/js/notice.min.js';
?>

</script>
<?php 
