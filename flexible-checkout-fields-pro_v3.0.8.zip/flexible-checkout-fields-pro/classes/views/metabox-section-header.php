<div class="panel woocommerce_options_panel fcf_panel">
    <h4><?php echo $section_title; ?></h4>
    <div class="options_group">