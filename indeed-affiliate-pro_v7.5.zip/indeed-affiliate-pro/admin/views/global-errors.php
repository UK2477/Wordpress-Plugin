<div class="<?php echo $data['err_class'];?> uap-global-error-wrapper">
<div class='uap-close-notice uap-js-close-admin-dashboard-notice'>x</div>
  <?php
echo '<p>' . esc_html__('This is a Trial Version of ', 'uap').'<strong>'. esc_html__(' Ultimate Affiliate Pro ', 'uap').'</strong>'. esc_html__(' plugin. Please add your purchase code into Licence section to enable the Full Ultimate Affiliate Pro Version. Check your ', 'uap') . '<a href="' . $data['url'] . '">' . esc_html__(' licence section ', 'uap') .'</a>.</p>';

?></div>
