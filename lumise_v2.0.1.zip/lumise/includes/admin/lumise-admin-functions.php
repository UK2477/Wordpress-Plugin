<?php
/**
 * Lumise Admin Functions
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
