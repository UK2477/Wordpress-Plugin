<?php
/**
 * Dropbox (v3) Manage functionality
 *
 * @package BackupBuddy
 */

require pb_backupbuddy::plugin_path() . '/destinations/dropbox2/_phpmin.php';
