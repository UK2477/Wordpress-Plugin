<?php
/**
 * Google Drive Auth API Credentials
 *
 * @package BackupBuddy
 */

return array(
	'GDRIVE_API_ID'       => '846948093153-cc5a1detpf3pp3cdinpg8pjon1a5efml.apps.googleusercontent.com',
	'GDRIVE_API_SECRET'   => 'w7Ai0ao287gn_LuPvXB5Zph6',
	'GDRIVE_REDIRECT_URI' => 'https://oauth-redirect.ithemes.com/googledrive/auth',
);
