<?php die(); // Test file for testing BackupBuddy remote transfers. You may delete this file if found on your destination server.
