<?php if(!defined('ABSPATH')) { exit; } // Exit if accessed directly
/*
Plugin Name: Aelia Tax Display by Country for WooCommerce
Plugin URI: https://aelia.co/shop/tax-display-by-country-for-woocommerce/
Description: Allows to display prices including/excluding tax depending on customer's location.
Author: Aelia
Author URI: https://aelia.co
Version: 1.16.0.210504
Text Domain: wc-aelia-tax-display-by-country
Domain Path: /languages
WC requires at least: 3.0
WC tested up to: 5.3
Required PHP: 7.0
*/

require_once(dirname(__FILE__) . '/src/lib/classes/install/aelia-wc-taxdisplaybycountry-requirementscheck.php');
// If requirements are not met, deactivate the plugin
if(Aelia_WC_TaxDisplayByCountry_RequirementsChecks::factory()->check_requirements()) {
	require_once dirname(__FILE__) . '/src/plugin-main.php';

	// Register this plugin file for auto-updates, if such capability exists
	if(!empty($GLOBALS['wc-aelia-tax-display-by-country']) && method_exists($GLOBALS['wc-aelia-tax-display-by-country'], 'set_main_plugin_file')) {
		// Set the path and name of the main plugin file (i.e. this file), for update
		// checks. This is needed because this is the main plugin file, but the updates
		// will be checked from within plugin-main.php
		$GLOBALS['wc-aelia-tax-display-by-country']->set_main_plugin_file(__FILE__);
	}
}
