This folder should contain all the images used by the plugin.
