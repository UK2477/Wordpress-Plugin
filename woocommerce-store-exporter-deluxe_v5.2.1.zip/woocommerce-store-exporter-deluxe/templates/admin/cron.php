<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title><?php _e( 'Store Exporter Deluxe', 'woocommerce-exporter' ); ?></title>
		<style type="text/css">
html {
	background: #f9f9f9;
}
body {
	background: #fff;
	color: #333;
	font-family: sans-serif;
	margin: 2em auto;
	padding: 1em 2em;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	border: 1px solid #dfdfdf;
	max-width: 700px;
}
p.text-small {
	color:#aaa;
}
textarea {
	font:12px Consolas, Monaco, Courier, monospace;
	width:100%;
	height:100%;
}
		</style>
	</head>
	<body>
