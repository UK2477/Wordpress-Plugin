<div class="postbox-container">
	<div class="postbox">
		<h3 class="hndle"><?php _e( 'Export File', 'woocommerce-exporter' ); ?></h3>
		<div class="inside">

			<textarea style="font:12px Consolas, Monaco, Courier, monospace; width:100%; height:200px;"><?php echo esc_textarea( $contents ); ?></textarea>

		</div>
		<!-- .inside -->
	</div>
	<!-- .postbox -->
</div>
<!-- .postbox-container -->
