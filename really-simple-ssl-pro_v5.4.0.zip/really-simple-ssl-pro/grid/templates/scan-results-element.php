<?php defined('ABSPATH') or die("you do not have access to this page!"); ?>

<tr>
    <td>
        <span class='rsssl-progress-status rsssl-open'><?php _e("Warning" , "really-simple-ssl-pro"); ?></span>
    </td>
    <td>
        [DESCRIPTION_BLOCKED_URL]
    </td>
    <td class="rsssl-blocked-url-link">
        [FILE]
    </td>
    <td class="rsssl-action-buttons">
        [RSSSL_FIX]
        [DETAILS]
    </td>
</tr>
