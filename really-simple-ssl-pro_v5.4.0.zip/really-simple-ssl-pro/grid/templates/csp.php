<?php
echo RSSSL_PRO()->rsssl_csp_backend->get_csp_table();