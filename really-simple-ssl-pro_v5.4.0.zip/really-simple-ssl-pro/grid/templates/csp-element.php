<tr>
    <td class="rsssl-csp-td">{date}</td>
    <td class="rsssl-csp-td"><a target="_blank" href="{documenturi}">{uri}</a></td>
    <td class="rsssl-csp-td">{violateddirective}</td>
    <td class="rsssl-csp-td">{blockeduri}</td>
    <td class="rsssl-csp-td"><button type="button" data-id="{data_id}" data-path=0 data-url=0 data-token="<?php echo wp_create_nonce('rsssl_fix_post');?>" class="button {id}" {modal} style="width: 80px; text-align: center;" >{button_text}</button></td>
</tr>
