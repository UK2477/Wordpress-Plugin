<?php defined('ABSPATH') or die("you do not have access to this page!"); ?>
<input type="submit" class="button button-secondary button-submit-ticket" value="<?php _e('Send', 'really-simple-ssl-pro') ?>">
</form>