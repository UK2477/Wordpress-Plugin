<?php
defined('ABSPATH') or die("you do not have access to this page!");
settings_fields('rlrsssl_pro_options');
do_settings_sections('rlrsssl_pro_settings_page');
do_action( "rsssl_premium_footer" );



