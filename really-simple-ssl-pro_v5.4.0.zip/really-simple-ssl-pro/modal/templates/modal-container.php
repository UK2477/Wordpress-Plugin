<div class="rsssl-modal" id="{id}">
    <div class="rsssl-modal-header">
        {header}
    </div>
    <div class="rsssl-modal-content">
        <div class="rsssl-modal-subtitle">
            {subtitle}
        </div>
        {content}
    </div>
    <div class="rsssl-modal-footer">
        {footer}
    </div>
</div>