<button type="button" data-results_id=0 data-id=0
        data-path=0 data-url=0
        data-token="{nonce}"
        class="button {class} rsssl-start-action"
        id="{id}">{button_text}
</button>