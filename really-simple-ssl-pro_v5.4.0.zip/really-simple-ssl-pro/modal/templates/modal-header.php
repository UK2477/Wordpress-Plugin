<h2 class="modal-title">
    {title}
</h2>
<button type="button" class="rsssl-modal-close" data-dismiss="modal"
        aria-label="Close"><img src="<?php echo rsssl_url . '/assets/cross.svg' ?>"/>
</button>