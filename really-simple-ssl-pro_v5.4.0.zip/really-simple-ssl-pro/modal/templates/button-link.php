<a class='button {class}' data-id=0 id='{id}'
   href='{href}' target="_blank">{button_text}</a>