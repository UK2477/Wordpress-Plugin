<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header( 'shop' );
do_action( 'woocommerce_before_main_content' );

$flag = false;
if(isset($_POST['mwb_track_package']))
{
	$flag = true;
	$mwb_user_order_id = $_POST['mwb_user_order_id'];
	update_option('mwb_tyo_user_order_id',$mwb_user_order_id);
}

?>
<div>
	<legend><h3><?php _e('Shipment Tracking','woocommerce-order-tracker'); ?></h3></legend>

	<form action="" method="POST" role="form">

		<div class="form-group">
			<label for=""><?php _e(' Enter Order Id ','woocommerce-order-tracker'); ?></label>
			<input type="text" class="form-control" id="mwb_tyo_order_id" name="mwb_user_order_id"  placeholder="Enter Order id">
		</div>
		<button type="submit" class="btn btn-primary mwb_tyo_button_track" name="mwb_track_package"><?php _e('Submit','woocommerce-order-tracker'); ?></button>
	</form>
</div>



<?php
if($flag)
{
	$mwb_tyo_selected_shipping_method = get_post_meta($mwb_user_order_id,'mwb_tyo_selected_shipping_service',true);

	if(isset($mwb_tyo_selected_shipping_method) && ($mwb_tyo_selected_shipping_method == 'canada_post'))
	{
		
		include_once  MWB_TRACK_YOUR_ORDER_PATH.'includes/MwbTyoEnableapi.php';
		$request = new MWB_Track_Your_Order_With_FedEx();
		$request->canadapost_request();
	}
	elseif(isset($mwb_tyo_selected_shipping_method) && ($mwb_tyo_selected_shipping_method == 'fedex'))
	{
		include_once  MWB_TRACK_YOUR_ORDER_PATH.'includes/MwbTyoEnableapi.php';
		$request = new MWB_Track_Your_Order_With_FedEx();
		$request->FedEx_request($mwb_user_order_id);	
	}
	elseif(isset($mwb_tyo_selected_shipping_method) && ($mwb_tyo_selected_shipping_method == 'usps'))
	{
		include_once  MWB_TRACK_YOUR_ORDER_PATH.'includes/MwbTyoEnableapi.php';
		$uspsrequest = new MWB_Track_Your_Order_With_FedEx();
		$uspsrequest->mwb_tyo_usps_tracking_request($mwb_user_order_id);	
	}
	else
	{
		?>
			<div class="mwb_tyo_shipment_tracking_warning_msg">
				<h4><?php _e('Service Not Available','woocommerce-order-tracker'); ?></h4>	
			</div>
		<?php
	}
	
}
do_action( 'woocommerce_after_main_content' );
get_footer('shop');
?>