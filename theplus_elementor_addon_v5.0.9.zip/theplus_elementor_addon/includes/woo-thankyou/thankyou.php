<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="woocommerce woocommerce-order tp-woocommerce-thankyou">
<?php
	do_action('theplus_thankyou_content');
?>
</div>
