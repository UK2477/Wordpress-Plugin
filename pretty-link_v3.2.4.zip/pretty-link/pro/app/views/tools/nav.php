<?php if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); } ?>

<li><a data-id="custom-bookmarklet"><?php esc_html_e('Custom Bookmarklet', 'pretty-link'); ?></a></li>

