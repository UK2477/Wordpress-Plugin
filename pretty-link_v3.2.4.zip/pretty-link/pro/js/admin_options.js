jQuery(document).ready(function($) {
  $('.plp-colorpicker').spectrum({
    showInput: true,
    preferredFormat: "hex"
  });
});

