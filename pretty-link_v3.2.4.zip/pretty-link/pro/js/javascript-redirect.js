setTimeout(function () {
    window.location = plpJsRedirectL10n.url;
}, plpJsRedirectL10n.delay);
