<?php if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); }

abstract class PrliBaseController {
  abstract public function load_hooks();
}

