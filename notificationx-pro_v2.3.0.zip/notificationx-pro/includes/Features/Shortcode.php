<?php
namespace NotificationXPro\Core;

use NotificationX\Core\PostType;
use NotificationX\GetInstance;
use NotificationXPro\Core\REST;
use NotificationXPro\FrontEnd\FrontEnd;

/**
 * Class Shortcode For NotificationX Pro
 * @since 1.2.3
 */
class Shortcode {
    /**
     * Instance of Shortcode
     *
     * @var Shortcode
     */
    use GetInstance;

    public $shortcode_nx_ids = [];

    /**
     * __construct__ is for revoke first time to get ready
     * @return void
     */
    public function __construct(){
        add_filter('nx_display_fields', array( $this, 'display_fields' ), 11 );
        add_filter('nx_add_in_queue', array( $this, 'only_as_shortcode' ), 10, 2 );
        add_shortcode('notificationx', array( $this, 'shortcode' ), 999 );
        add_action('wp_print_footer_scripts', [$this, 'footer_scripts']);
    }

    /**
     * Customize tab fields added
     * @param array $options
     * @return array
     */
    public function display_fields( $options ) {
        $options['visibility']['fields']['show_on']['options']['only_shortcode'] = [
            'label' => __('Use Only as Shortcode', 'notificationx-pro'),
            'value' => 'only_shortcode',
        ];
        return $options;
    }

    /**
     * Use notification only as shortcode
     * @param string $type
     * @param mixed $settings
     */
    public function only_as_shortcode( $type, $settings ){
        if( isset( $settings->show_on ) && $settings->show_on === 'only_shortcode' ) {
            return false;
        }
        return $type;
    }

    /**
     * this method is responsible for output the shortcode.
     * @param array $atts
     */
    public function shortcode( $atts, $content = null ){
        $atts = shortcode_atts( array(
            'id' => '',
        ), $atts, 'notificationx' );

        if( empty( $atts['id'] ) ) {
            return '<p class="nx-shortcode-notice">'. __( 'You have to give an ID to generate notification.', 'notificationx-pro' ) .'</p>';
        }

        if(!PostType::get_instance()->is_enabled($atts['id'])) {
            return '<p class="nx-shortcode-notice">'. __( 'Make sure you have enabled the notification which ID you have given.', 'notificationx-pro' ) .'</p>';
        }

        $this->shortcode_nx_ids[] = $atts['id'];
        $output = "<div id='notificationx-shortcode-{$atts['id']}' class='notificationx-shortcode-wrapper'></div>";
        return $output;
    }

    public function footer_scripts(){
        if(!empty($this->shortcode_nx_ids)){
            $data = FrontEnd::get_instance()->get_notifications_ids();
            if(empty($data['total'])):
                do_action('notificationx_scripts');
                $notificationX = [
                    'global'   => [],
                    'active'   => [],
                    'shortcode'   => $this->shortcode_nx_ids,
                    'pressbar' => [],
                    'rest'     => REST::get_instance()->rest_data(),
                ];
                ?>
                <script>
                var notificationX = <?php echo json_encode($notificationX);?>;
                </script>
                <?php
                wp_print_scripts('notificationx-public');
                wp_print_styles('notificationx-public');
                wp_print_scripts('notificationx-pro-public');
                wp_print_styles('notificationx-pro-public');
            else:
            ?>
                <script>
                notificationX = notificationX || {shortcode: []};
                notificationX.shortcode = <?php echo json_encode($this->shortcode_nx_ids);?>;
                </script>
            <?php
            endif;
        }
    }
}