<?php

/**
 * Extension Factory
 *
 * @package NotificationX\Extensions
 */

namespace NotificationXPro\Admin;

use NotificationX\Core\Helper as HelperFree;
use NotificationX\GetInstance;
use NotificationX\ThirdParty\WPML;
use NotificationXPro\Core\Helper;

class XSS {

    use GetInstance;

    public function __construct()
    {
        add_filter('nx_builder_configs', [$this, 'builder_configs']);
        add_filter('nx_settings_xss_code_default', [$this, 'settings_field_xss_code']);
    }

    public function get_localize_data($data = []){
        $data = apply_filters('nx_frontend_localize_data', $data);
        if(isset($data['rest']['nonce'])){
            unset($data['rest']['nonce']);
        }
        return $data;
    }

    public function builder_configs($tabs){
        $tabs['xss_data']    = $this->get_localize_data();
        $tabs['xss_scripts'] = $this->get_scripts();
        return $tabs;
    }
    public function settings_field_xss_code($xss_code){
        $xss_code = "<script>notificationX = " . json_encode($this->get_localize_data(['all_active' => true])) . "</script>";
        $xss_code .= $this->get_scripts();
        return $xss_code;
    }

    public function get_scripts(){
        $xss_scripts    = "\n<div id='notificationx-frontend'></div>";
        $moment_locale  = WPML::get_instance()->localize_moment(null, true);
        $scripts = [
            'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.33/moment-timezone-with-data.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.33/moment-timezone-utils.js',
            'https://unpkg.com/react@17/umd/react.production.min.js',
            'https://unpkg.com/react-dom@17/umd/react-dom.production.min.js',
            HelperFree::file('public/js/crossSite.js', true),
        ];
        $styles = [
            HelperFree::file('public/css/crossSite.css', true),
            Helper::pro_file('public/css/frontend.css', true),
        ];

        if($moment_locale){
            $scripts[] = $moment_locale;
        }

        foreach ($styles as $style) {
            $xss_scripts .= "\n<link rel='stylesheet' href='$style' media='all' />";
        }
        foreach ($scripts as $script) {
            $xss_scripts .= "\n<script src='$script'></script>"; /// crossorigin='anonymous'
        }


        return $xss_scripts;
    }
}