<?php

namespace NotificationXPro\Extensions\Freemius;

class Freemius_InvalidArgumentException extends Freemius_Exception { }