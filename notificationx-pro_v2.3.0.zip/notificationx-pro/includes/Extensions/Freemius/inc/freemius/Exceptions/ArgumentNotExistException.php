<?php

namespace NotificationXPro\Extensions\Freemius;

class Freemius_ArgumentNotExistException extends Freemius_InvalidArgumentException {

}