<?php
/**
 * EDD Extension
 *
 * @package NotificationX\Extensions
 */

namespace NotificationXPro\Extensions\EDD;

use NotificationX\Core\Rules;
use NotificationX\Extensions\EDD\EDD as EDDFree;
use NotificationX\Extensions\GlobalFields as GlobalFieldsFree;
use NotificationXPro\Extensions\GlobalFields;

/**
 * EDD Extension
 * @todo normalize data for frontend.
 * @todo show_purchaseof && excludes_product
 */
class EDD extends EDDFree {


    /**
     * Initially Invoked when initialized.
     */
    public function __construct() {
        parent::__construct();
    }


    public function init(){
        parent::init();

    }

    public function init_fields(){
        parent::init_fields();
        add_filter( 'nx_content_fields', array( $this, 'content_fields' ) );
        add_filter('nx_combine_multiorder_text_dependency', [$this, 'multiorder_text_dependency']);
        add_filter('nx_conversion_product_list', [$this, 'products']);
        add_filter('nx_conversion_category_list', [$this, 'categories']);

    }


    public function public_actions(){
        parent::public_actions();
        if (!$this->is_active()) {
            return;
        }

        add_filter("nx_filtered_data_{$this->id}", array($this->get_type(), 'excludes_product'), 11, 3);
        add_filter("nx_filtered_data_{$this->id}", array($this->get_type(), 'show_purchaseof'), 11, 3);
    }

    public function content_fields($fields){
        $content_fields = &$fields['content']['fields'];

        $content_fields['template'] = array(
            'type'     => 'template',
            'name'     => 'template',
            'priority' => 90,
            'defaults' => [
                __('{{name}} recently purchased', 'notificationx-pro'), '{{title}}', '{{time}}'
            ],
            'variables' => [
                '{{name}}', '{{first_name}}', '{{last_name}}', '{{title}}', '{{time}}'
            ],
            'rules'       => Rules::is( 'source', $this->id ),
        );


        $content_fields['product_control']    = Rules::includes('source', $this->id, false, $content_fields['product_control']);
        $content_fields['category_list']      = Rules::includes('source', $this->id, false, $content_fields['category_list']);
        $content_fields['product_list']       = Rules::includes('source', $this->id, false, $content_fields['product_list']);
        $content_fields['product_exclude_by'] = Rules::includes('source', $this->id, false, $content_fields['product_exclude_by']);
        $content_fields['exclude_categories'] = Rules::includes('source', $this->id, false, $content_fields['exclude_categories']);
        $content_fields['exclude_products']   = Rules::includes('source', $this->id, false, $content_fields['exclude_products']);

        return $fields;
    }


    /**
     * Adding fields in the metabox.
     *
     * @param array $args Settings arguments.
     * @return mixed
     */
    public function multiorder_text_dependency($dependency) {
        $dependency[] = $this->id;
        return $dependency;
    }



    public function categories($options){

        $product_categories = get_terms(array(
            'taxonomy'   => 'download_category',
            'hide_empty' => false,
        ));

        $category_list = [];

        if( ! is_wp_error( $product_categories ) ) {
            foreach( $product_categories as $product ) {
                $category_list[ $product->slug ] = $product->name;
            }
        }

        $_options = GlobalFields::get_instance()->normalize_fields($category_list, 'source', $this->id);
        return array_merge($options, $_options);
    }

    public function products($options){
        $products = get_posts(array(
            'post_type'      => 'download',
            'posts_per_page' => -1,
            'numberposts' => -1,
        ));

        $product_list = [];

        if( ! empty( $products ) ) {
            foreach( $products as $product ) {
                $product_list[ $product->ID ] = $product->post_title;
            }
        }
        $_options = GlobalFields::get_instance()->normalize_fields($product_list, 'source', $this->id);
        return array_merge($options, $_options);
    }
}