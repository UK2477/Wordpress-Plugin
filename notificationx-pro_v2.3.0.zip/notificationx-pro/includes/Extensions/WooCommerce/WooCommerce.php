<?php
/**
 * WooCommerce Extension
 *
 * @package NotificationX\Extensions
 */

namespace NotificationXPro\Extensions\WooCommerce;

use NotificationX\Extensions\WooCommerce\WooCommerce as WooCommerceFree;
use NotificationX\Extensions\GlobalFields;

/**
 * WooCommerce Extension Class
 */
class WooCommerce extends WooCommerceFree {


    /**
     * Initially Invoked when initialized.
     */
    public function __construct() {
        parent::__construct();
    }



    public function init(){
        parent::init();
        add_filter('nx_combine_multiorder_text_dependency', [$this, 'multiorder_text_dependency']);
        // add_filter('nx_content_fields', [$this, 'content_fields']);
    }



    public function public_actions(){
        parent::public_actions();
        if (!$this->is_active()) {
            return;
        }

        add_filter("nx_filtered_data_{$this->id}", array($this->get_type(), 'excludes_product'), 11, 3);
        add_filter("nx_filtered_data_{$this->id}", array($this->get_type(), 'show_purchaseof'), 11, 3);
    }

    public function multiorder_text_dependency($dependency) {
        $dependency[] = $this->id;
        return $dependency;
    }
}