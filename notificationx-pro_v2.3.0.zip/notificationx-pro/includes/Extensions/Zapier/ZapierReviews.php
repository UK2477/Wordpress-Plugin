<?php
/**
 * Zapier Extension
 *
 * @package NotificationX\Extensions
 */

namespace NotificationXPro\Extensions\Zapier;

use NotificationX\GetInstance;
use NotificationX\Extensions\Extension;
use NotificationX\Extensions\Zapier\ZapierReviews as ZapierReviewsFree;

/**
 * Zapier Extension
 */
class ZapierReviews extends ZapierReviewsFree {
    use Zapier;

    /**
     * Initially Invoked when initialized.
     */
    public function __construct() {
        parent::__construct();
        /**
         * @since 1.1.3
         */
        add_action('nx_api_response_success', array($this, 'get_response'));
    }

}
