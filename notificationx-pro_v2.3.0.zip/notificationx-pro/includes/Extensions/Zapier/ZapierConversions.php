<?php
/**
 * Zapier Extension
 *
 * @package NotificationX\Extensions
 */

namespace NotificationXPro\Extensions\Zapier;

use NotificationX\GetInstance;
use NotificationX\Extensions\Extension;
use NotificationX\Extensions\Zapier\ZapierConversions as ZapierConversionsFree;

/**
 * Zapier Extension
 */
class ZapierConversions extends ZapierConversionsFree {
    /**
     * Instance of Zapier
     *
     * @var Zapier
     */
    use Zapier;

    /**
     * Initially Invoked when initialized.
     */
    public function __construct() {
        parent::__construct();
        /**
         * @since 1.1.3
         */
        add_action('nx_api_response_success', array($this, 'get_response'));
    }

}
