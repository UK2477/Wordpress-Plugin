jQuery(document).ready(function () {
    'use strict';
    if (!jQuery('.xoo-wsc-modal').hasClass('xoo-wsc-active')) {
        jQuery('.xoo-wsc-basket').click();
    }
});