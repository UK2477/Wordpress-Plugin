<template functional>
  <div class="wpcd-fs-wait-block-wrapper">
    <div class="wpcd-fs-wait-block"></div>
    <div class="wpcd-fs-wait-block"></div>
    <div class="wpcd-fs-wait-block"></div>
  </div>
</template>
